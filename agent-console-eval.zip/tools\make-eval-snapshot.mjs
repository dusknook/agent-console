#!/usr/bin/env node
/**
 * 采集评测包所需的快照 —— 全部来自**运行中的真实服务**，不是手抄的。
 *
 * 为什么要有这个脚本：手抄的快照会过时、会撒谎，而评测包的全部价值就在于
 * 「评估者看到的，就是服务真的会给的」。所以快照必须能被重新生成，并且带 digest。
 *
 * 用法： node tools/make-eval-snapshot.mjs [--base http://127.0.0.1:8787] [--out EVAL-PACKAGE/snapshot]
 */
import fs from 'node:fs';
import path from 'node:path';

const args = process.argv.slice(2);
const argOf = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const BASE = argOf('--base', 'http://127.0.0.1:8787');
const OUT = path.resolve(argOf('--out', 'EVAL-PACKAGE/snapshot'));

const get = async p => {
  const r = await fetch(BASE + p);
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  return { status: r.status, ctype: r.headers.get('content-type'), bytes: Buffer.byteLength(text), text, json, headers: Object.fromEntries(r.headers.entries()) };
};
const post = async (p, body, headers) => {
  const r = await fetch(BASE + p, { method: 'POST',
    headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}),
    body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  return { status: r.status, ctype: r.headers.get('content-type'), bytes: Buffer.byteLength(text), text, json };
};
const write = (name, obj) => {
  fs.mkdirSync(OUT, { recursive: true });
  const p = path.join(OUT, name);
  fs.writeFileSync(p, typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2));
  console.log('  写出 ' + name + '  (' + fs.statSync(p).size + 'B)');
};

(async () => {
  console.log('采集快照 ← ' + BASE + '  →  ' + OUT);
  await post('/v1/demo/reset');

  // 1. 自举：零知识 agent 的第一次请求（不带 Accept，模拟 */*）
  const root = await get('/');
  write('bootstrap-root.sample.json', {
    _note: '一个零知识 agent 打 GET / 时拿到的。不带 Accept 头（等于 */*，多数 HTTP 客户端的默认值）。' +
           '内容协商：只有明确偏好 text/html 才给页面，否则给这份机器可读索引。',
    status: root.status, content_type: root.ctype, bytes: root.bytes,
    body: root.json || root.text.slice(0, 400)
  });

  // 2. health
  const health = await get('/v1/health');
  write('health.sample.json', {
    _note: '自举入口。routes[] 给出全部路由，agent 据此知道这里有什么。',
    status: health.status, content_type: health.ctype, bytes: health.bytes, body: health.json
  });

  // 3. 撞门控：本包最重要的一份
  const q = await post('/v1/act/queue', { kind: 'eval_sample', shard: 'EV', cost_cny: 0.42, route: 'approve' },
    { 'Idempotency-Key': 'eval-snapshot-' + Date.now() });
  const actionId = q.json && q.json.data && q.json.data.id;
  const conf = await post('/v1/act/' + actionId + '/confirm', {});
  write('gate-403.sample.json', {
    _note: '★ 最重要的一份：agent 调用一个被门控的端点时，真实拿到的完整响应。' +
           '注意 hints[].action —— 那是给 agent 做分支的机器语义（ASCII 枚举），' +
           'suggest/why 是给人读的散文。两者分开，是因为跨语区模型对中文原文没有稳定的解析契约。',
    request: { method: 'POST', path: '/v1/act/{id}/confirm', body: {} },
    status: conf.status, content_type: conf.ctype, bytes: conf.bytes, body: conf.json
  });

  // 4. 单查那张单子
  const aprId = conf.json && conf.json.error && conf.json.error.approval_id;
  const single = await get('/v1/approvals/' + aprId);
  write('approval-single.sample.json', {
    _note: 'agent 手握 approval_id 后的 O(1) 查询路径。注意 requires 随状态变：' +
           '还挂着时是 human（谁说了算在人），裁决后转 auto。next_step 是结构化字段，不是散文。',
    status: single.status, bytes: single.bytes, body: single.json
  });

  // 5. 契约
  const spec = await get('/v1/openapi.json');
  write('contract.openapi.json', spec.json || { error: 'not json' });
  write('contract.transport-headers.txt',
    '这是 GET /v1/openapi.json 的响应头。\n' +
    '注意：文档体里**没有** _meta —— 传输统计放在头里。\n' +
    '理由：文档的全部价值在于描述那份契约，而契约不随请求变。\n' +
    '把 request_id / latency 塞进文档体，等于把「可 diff」这个能力白送掉。\n\n' +
    Object.entries(spec.headers).map(([k, v]) => k + ': ' + v).join('\n') + '\n');

  // 6. agent-trial 的机器可读数据
  const trialPath = path.resolve('EVAL-PACKAGE/agent-trial-baseline.json');
  if (fs.existsSync(trialPath)) {
    console.log('  （agent-trial-baseline.json 已存在，由 agent-trial.mjs --json 生成，不覆盖）');
  } else {
    console.log('  提示：agent-trial-baseline.json 请用 `node agent-trial.mjs --json EVAL-PACKAGE/agent-trial-baseline.json` 生成');
  }

  // 7. 索引
  write('README.md', [
    '# snapshot/ —— 全部来自运行中的真实服务，非手抄',
    '',
    '生成命令：`node tools/make-eval-snapshot.mjs`（服务需在 8787 运行）',
    '生成时间：' + new Date().toISOString(),
    '来源：' + BASE,
    '',
    '| 文件 | 是什么 |',
    '|---|---|',
    '| `bootstrap-root.sample.json` | 零知识 agent 第一次打 `GET /` 拿到什么（内容协商） |',
    '| `health.sample.json` | 自举入口：端点清单 |',
    '| `gate-403.sample.json` | **★ 最重要**：被门控时 agent 真实拿到的完整响应 |',
    '| `approval-single.sample.json` | 单查审批单（`requires` 随状态变） |',
    '| `contract.openapi.json` | 完整契约（现场派生，可 diff） |',
    '| `contract.transport-headers.txt` | 契约的响应头 —— 传输元数据在这里，不在文档体里 |',
    '| `agent-trial-baseline.json` | AI 视角测评的原始判定数据（机器可读） |',
    '',
    '**这些文件会过时。** 如果你要下结论，请以自己实际调用服务的结果为准；',
    '或者重跑上面的生成命令刷新它们。',
    ''
  ].join('\n'));

  console.log('\n采集完成。');
})().catch(e => { console.error('采集失败：' + e.message); process.exitCode = 1; });
