# snapshot/ —— 全部来自运行中的真实服务，非手抄

生成命令：`node tools/make-eval-snapshot.mjs`（服务需在 8787 运行）
生成时间：2026-10-03T10:25:17.461Z
来源：http://127.0.0.1:8787

| 文件 | 是什么 |
|---|---|
| `bootstrap-root.sample.json` | 零知识 agent 第一次打 `GET /` 拿到什么（内容协商） |
| `health.sample.json` | 自举入口：端点清单 |
| `gate-403.sample.json` | **★ 最重要**：被门控时 agent 真实拿到的完整响应 |
| `approval-single.sample.json` | 单查审批单（`requires` 随状态变） |
| `contract.openapi.json` | 完整契约（现场派生，可 diff） |
| `contract.transport-headers.txt` | 契约的响应头 —— 传输元数据在这里，不在文档体里 |
| `agent-trial-baseline.json` | AI 视角测评的原始判定数据（机器可读） |

**这些文件会过时。** 如果你要下结论，请以自己实际调用服务的结果为准；
或者重跑上面的生成命令刷新它们。
